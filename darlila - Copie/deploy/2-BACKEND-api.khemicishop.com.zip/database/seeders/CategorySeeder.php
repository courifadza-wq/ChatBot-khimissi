<?php

namespace Database\Seeders;

use App\Models\Category;
use Illuminate\Database\Seeder;

class CategorySeeder extends Seeder
{
    /**
     * Les 8 univers de la boutique.
     */
    public function run(): void
    {
        $categories = [
            [
                'slug' => 'bijoux-traditionnels',
                'name_fr' => 'Bijoux traditionnels',
                'name_ar' => 'مجوهرات تقليدية',
                'description_fr' => 'Argent, filigrane et pierres naturelles.',
                'description_ar' => 'فضة وفتيلة وأحجار طبيعية.',
            ],
            [
                'slug' => 'vetements-brodes',
                'name_fr' => 'Vêtements brodés',
                'name_ar' => 'ملابس مطرزة',
                'description_fr' => 'Caftans et tenues brodées main.',
                'description_ar' => 'قفاطين وأزياء مطرزة يدويًا.',
            ],
            [
                'slug' => 'deco-poterie',
                'name_fr' => 'Déco & poterie',
                'name_ar' => 'ديكور وفخار',
                'description_fr' => 'Céramiques peintes à la main.',
                'description_ar' => 'سيراميك مرسوم يدويًا.',
            ],
            [
                'slug' => 'accessoires-en-cuir',
                'name_fr' => 'Accessoires en cuir',
                'name_ar' => 'إكسسوارات جلدية',
                'description_fr' => 'Sacs et sandales en cuir véritable.',
                'description_ar' => 'حقائب وصنادل من الجلد الطبيعي.',
            ],
            [
                'slug' => 'parfums',
                'name_fr' => 'Parfums',
                'name_ar' => 'عطور',
                'description_fr' => 'Des fragrances élégantes pour chaque moment.',
                'description_ar' => 'روائح أنيقة لكل لحظة.',
            ],
            [
                'slug' => 'cosmetiques',
                'name_fr' => 'Cosmétiques',
                'name_ar' => 'مستحضرات التجميل',
                'description_fr' => 'Soins et beauté pour prendre soin de vous.',
                'description_ar' => 'منتجات للعناية والجمال.',
            ],
            [
                'slug' => 'articles-pour-bebe',
                'name_fr' => 'Articles pour bébé',
                'name_ar' => 'مستلزمات الأطفال',
                'description_fr' => 'Des essentiels doux et sûrs pour bébé.',
                'description_ar' => 'احتياجات ناعمة وآمنة لطفلك.',
            ],
            [
                'slug' => 'hygiene-bebe',
                'name_fr' => 'Hygiène bébé',
                'name_ar' => 'نظافة الطفل',
                'description_fr' => 'Des soins quotidiens doux pour les tout-petits.',
                'description_ar' => 'منتجات لطيفة للعناية اليومية بصغيرك.',
            ],
        ];

        foreach ($categories as $index => $category) {
            Category::updateOrCreate(
                ['slug' => $category['slug']],
                $category + ['position' => ($index + 1) * 10]
            );
        }
    }
}
